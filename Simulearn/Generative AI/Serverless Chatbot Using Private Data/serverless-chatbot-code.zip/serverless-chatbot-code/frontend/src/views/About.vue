<template>
  <div class="about container bg-light p-3 rounded">
    <h2>About</h2>
    This is an about page.
  </div>
</template>